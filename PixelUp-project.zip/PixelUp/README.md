# PixelUp

Offline photo enhancer for Android (10+).

- Welcome screen shown once, then never again (SharedPreferences flag).
- Home screen with four cards. **Enhance & Upscale** works; the other three are "Coming soon" placeholders.
- Enhance & Upscale: pick a photo from the gallery, choose Auto/2x/3x/4x and sharpness, compare original vs enhanced, save as a **new** image in `Pictures/PixelUp`. The original is only read, never written.
- Fully offline: no INTERNET permission, no dependencies.

## Get the APK

**Option A: GitHub (no setup on your PC).** Push this folder to a new GitHub repo. The *Build APK* workflow runs automatically; download `PixelUp-debug-apk` from the run's *Artifacts*. Unzip and install `app-debug.apk` (allow "install unknown apps").

**Option B: Android Studio.** Open this folder, let it sync, then *Build > Build APK(s)*.

**Option C: Command line** (JDK 17 + Android SDK installed):

    ./gradlew assembleDebug
    # -> app/build/outputs/apk/debug/app-debug.apk

## How the upscaling works

`Upscaler.java` (pure Java): premultiplied-alpha Lanczos-3 resampling, then a light 3x3 unsharp mask. "Auto" aims for ~3000 px on the long side (max 4x) and is capped at 16 MP output for memory safety.

Check it on any computer with a JDK:

    javac -d /tmp/up app/src/main/java/com/pixelup/app/Upscaler.java verify/UpscalerCheck.java
    java -cp /tmp/up UpscalerCheck
