import com.pixelup.app.Upscaler;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Plain-JVM checks for the offline upscaler (no Android needed).
 * Run from the project root:
 *   javac -d /tmp/up app/src/main/java/com/pixelup/app/Upscaler.java verify/UpscalerCheck.java
 *   java -cp /tmp/up UpscalerCheck
 */
public class UpscalerCheck {
    static int fails = 0;

    static void check(boolean ok, String msg) {
        System.out.println((ok ? "PASS  " : "FAIL  ") + msg);
        if (!ok) fails++;
    }

    static int[] upscale(int[] src, int sw, int sh, int dw, int dh, float sharp) {
        int[] out = new int[dw * dh];
        boolean ok = Upscaler.run(src, sw, sh, dw, dh, sharp,
                (y, row) -> System.arraycopy(row, 0, out, y * dw, dw), null);
        if (!ok) throw new RuntimeException("unexpected cancel");
        return out;
    }

    // ---------- synthetic test picture: edges, curves, stripes, checker, thin line, gradient ----------
    // Features are deliberately NOT aligned to a 2x2 grid (7px checker, period-5 diagonal stripes,
    // sub-pixel line), and every pixel is 4x4 supersampled so edges are anti-aliased like a camera
    // image. Grid-aligned content would unfairly favour nearest-neighbour after a 2x box shrink.
    static double scene(double px, double py, int n) {
        double fx = px / n, fy = py / n;
        double g = 80 + 100 * fx;
        double dx = px - n * 0.5, dy = py - n * 0.5;
        if (dx * dx + dy * dy < (0.2 * n) * (0.2 * n)) g = 230;
        if (fx < 0.4 && fy > 0.6 && (((int) Math.floor((px + py) / 5.0)) & 1) == 0) g = 30;
        if (fx > 0.6 && fy < 0.4) {
            g = ((((int) Math.floor(px / 7.0)) + ((int) Math.floor(py / 7.0))) & 1) == 0 ? 250 : 20;
        }
        if (Math.abs(py - (0.25 * n + 0.3 * px)) < 0.9) g = 0;
        return g;
    }

    static int[] makeTest(int n) {
        int[] px = new int[n * n];
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                double sum = 0;
                for (int j = 0; j < 4; j++)
                    for (int i = 0; i < 4; i++)
                        sum += scene(x + (i + 0.5) / 4, y + (j + 0.5) / 4, n);
                double g = sum / 16.0;
                int c = (int) Math.round(g);
                int c2 = (int) Math.round(g * 0.9);
                int c3 = (int) Math.round(g * 0.8);
                px[y * n + x] = 0xFF000000 | (c << 16) | (c2 << 8) | c3;
            }
        }
        return px;
    }

    static int[] boxDown2(int[] s, int n) {
        int m = n / 2;
        int[] o = new int[m * m];
        for (int y = 0; y < m; y++)
            for (int x = 0; x < m; x++) {
                int r = 0, g = 0, b = 0;
                for (int j = 0; j < 2; j++)
                    for (int i = 0; i < 2; i++) {
                        int p = s[(2 * y + j) * n + 2 * x + i];
                        r += (p >> 16) & 255;
                        g += (p >> 8) & 255;
                        b += p & 255;
                    }
                o[y * m + x] = 0xFF000000 | ((r / 4) << 16) | ((g / 4) << 8) | (b / 4);
            }
        return o;
    }

    static int[] nearest(int[] s, int sw, int sh, int dw, int dh) {
        int[] o = new int[dw * dh];
        for (int y = 0; y < dh; y++)
            for (int x = 0; x < dw; x++)
                o[y * dw + x] = s[Math.min(sh - 1, y * sh / dh) * sw + Math.min(sw - 1, x * sw / dw)];
        return o;
    }

    static int[] bilinear(int[] s, int sw, int sh, int dw, int dh) {
        int[] o = new int[dw * dh];
        for (int y = 0; y < dh; y++) {
            double sy = Math.max(0, Math.min(sh - 1, (y + 0.5) * sh / dh - 0.5));
            int y0 = (int) Math.floor(sy), y1 = Math.min(sh - 1, y0 + 1);
            double fy = sy - y0;
            for (int x = 0; x < dw; x++) {
                double sx = Math.max(0, Math.min(sw - 1, (x + 0.5) * sw / dw - 0.5));
                int x0 = (int) Math.floor(sx), x1 = Math.min(sw - 1, x0 + 1);
                double fx = sx - x0;
                int res = 0xFF000000;
                for (int sh2 = 16; sh2 >= 0; sh2 -= 8) {
                    double v = ((s[y0 * sw + x0] >> sh2) & 255) * (1 - fx) * (1 - fy)
                            + ((s[y0 * sw + x1] >> sh2) & 255) * fx * (1 - fy)
                            + ((s[y1 * sw + x0] >> sh2) & 255) * (1 - fx) * fy
                            + ((s[y1 * sw + x1] >> sh2) & 255) * fx * fy;
                    res |= ((int) Math.round(v)) << sh2;
                }
                o[y * dw + x] = res;
            }
        }
        return o;
    }

    static double psnr(int[] a, int[] b) {
        double se = 0;
        for (int i = 0; i < a.length; i++)
            for (int sh = 16; sh >= 0; sh -= 8) {
                int d = ((a[i] >> sh) & 255) - ((b[i] >> sh) & 255);
                se += d * d;
            }
        double mse = se / (a.length * 3.0);
        return mse == 0 ? 99 : 10 * Math.log10(255.0 * 255.0 / mse);
    }

    public static void main(String[] args) {
        // 1. Flat colour stays flat (no ringing/halo from the filter or the sharpener)
        {
            int[] src = new int[10 * 7];
            java.util.Arrays.fill(src, 0xFF336699);
            int[] out = upscale(src, 10, 7, 30, 21, 0.9f);
            boolean flat = true;
            for (int p : out) flat &= (p == 0xFF336699);
            check(flat, "flat colour stays exactly flat after 3x upscale + sharpen");
        }

        // 2. Scale 1, sharpen 0 is an exact identity
        {
            Random rnd = new Random(1);
            int[] src = new int[37 * 23];
            for (int i = 0; i < src.length; i++) src[i] = 0xFF000000 | rnd.nextInt(0x1000000);
            int[] out = upscale(src, 37, 23, 37, 23, 0f);
            check(java.util.Arrays.equals(src, out), "1x with no sharpening reproduces the input exactly");
        }

        // 3. Every output row delivered once, in order, with correct width
        {
            int[] src = makeTest(40);
            List<Integer> ys = new ArrayList<>();
            boolean widthOk = true;
            final boolean[] w = {true};
            Upscaler.run(src, 40, 40, 100, 120, 0.5f, (y, row) -> {
                ys.add(y);
                if (row.length != 100) w[0] = false;
            }, null);
            boolean order = ys.size() == 120;
            for (int i = 0; i < ys.size(); i++) order &= ys.get(i) == i;
            check(order && w[0], "all 120 rows written once, in order, width 100");
        }

        // 4. Transparency: no colour bleeding from fully transparent pixels, opaque side intact
        {
            int w = 8, h = 8;
            int[] src = new int[w * h];
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    src[y * w + x] = x < 4 ? 0x00FF0000 : 0xFF0000FF; // transparent red | opaque blue
            int[] out = upscale(src, w, h, 16, 16, 0.5f);
            boolean noRed = true;
            for (int p : out) noRed &= (((p >> 16) & 255) == 0);
            check(noRed, "no red bleeds in from the transparent side");
            check(out[8 * 16 + 0] == 0, "fully transparent area stays fully transparent");
            check(out[8 * 16 + 15] == 0xFF0000FF, "opaque area keeps its exact colour");
        }

        // 5. Quality: rebuild a picture from a half-size copy; compare against the true original
        {
            int n = 256;
            int[] orig = makeTest(n);
            int[] small = boxDown2(orig, n);
            double pNearest = psnr(orig, nearest(small, n / 2, n / 2, n, n));
            double pBilinear = psnr(orig, bilinear(small, n / 2, n / 2, n, n));
            double pLanczos = psnr(orig, upscale(small, n / 2, n / 2, n, n, 0f));
            double pLanSharp = psnr(orig, upscale(small, n / 2, n / 2, n, n, 0.6f));
            System.out.printf("      PSNR vs original (dB, higher = closer):%n");
            System.out.printf("        nearest        %.2f%n", pNearest);
            System.out.printf("        bilinear       %.2f%n", pBilinear);
            System.out.printf("        Lanczos        %.2f%n", pLanczos);
            System.out.printf("        Lanczos+sharp  %.2f  (app default)%n", pLanSharp);
            check(pLanczos > pBilinear && pBilinear > pNearest, "Lanczos > bilinear > nearest on the test picture");
            check(pLanSharp > pBilinear, "default app setting (Lanczos + 0.6 sharpen) still beats bilinear");
        }

        // 6. Cancellation
        {
            int[] src = makeTest(64);
            boolean ok = Upscaler.run(src, 64, 64, 128, 128, 0.5f, (y, row) -> {
            }, new Upscaler.Progress() {
                public void onProgress(int p) {
                }

                public boolean isCancelled() {
                    return true;
                }
            });
            check(!ok, "cancel request makes run() return false");
        }

        // 7. Progress is monotonic and reaches 100
        {
            int[] src = makeTest(64);
            final int[] last = {-1};
            final boolean[] mono = {true};
            Upscaler.run(src, 64, 64, 192, 192, 0.5f, (y, row) -> {
            }, new Upscaler.Progress() {
                public void onProgress(int p) {
                    if (p < last[0]) mono[0] = false;
                    last[0] = p;
                }

                public boolean isCancelled() {
                    return false;
                }
            });
            check(mono[0] && last[0] == 100, "progress never goes backwards and ends at 100");
        }

        // 8. Automatic scale choice
        {
            check(Upscaler.effectiveScale(500, 500, 0) == 4f, "auto: 500x500 -> 4x");
            check(Upscaler.effectiveScale(1000, 800, 0) == 3f, "auto: 1000x800 -> 3x");
            check(Upscaler.effectiveScale(2000, 1500, 0) == 2f, "auto: 2000x1500 -> 2x");
            check(Upscaler.effectiveScale(4000, 3000, 0) == 1f, "auto: 4000x3000 already large -> 1x (enhance only)");
            check(Upscaler.effectiveScale(2900, 2000, 0) == 1.5f, "auto: 2900x2000 capped by memory limit -> 1.5x");
            check(Upscaler.effectiveScale(1500, 1500, 4f) == 2.5f, "manual 4x on 1500x1500 capped to 2.5x");
            check(Upscaler.effectiveScale(6000, 4000, 4f) == 1f, "24 MP photo never enlarged");
            int sw = 2900, sh = 2000;
            float s = Upscaler.effectiveScale(sw, sh, 0);
            check((long) Upscaler.scaledSize(sw, s) * Upscaler.scaledSize(sh, s) <= Upscaler.MAX_OUT_PIXELS,
                    "output pixel count stays within the cap");
        }

        // 9. Speed / memory sanity at a realistic size: 2000x1500 -> 4000x3000 (12 MP)
        {
            Random rnd = new Random(7);
            int sw = 2000, sh = 1500;
            int[] src = new int[sw * sh];
            for (int i = 0; i < src.length; i++) src[i] = 0xFF000000 | rnd.nextInt(0x1000000);
            long t0 = System.nanoTime();
            long[] sum = {0};
            Upscaler.run(src, sw, sh, 4000, 3000, 0.6f, (y, row) -> sum[0] += row[y % 4000], null);
            long ms = (System.nanoTime() - t0) / 1_000_000;
            long usedMb = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) >> 20;
            System.out.println("      2000x1500 -> 4000x3000 took " + ms + " ms on this JVM (heap in use ~" + usedMb + " MB)");
            check(ms < 60000, "12 MP result completes");
        }

        System.out.println(fails == 0 ? "\nALL CHECKS PASSED" : "\n" + fails + " CHECK(S) FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }
}
