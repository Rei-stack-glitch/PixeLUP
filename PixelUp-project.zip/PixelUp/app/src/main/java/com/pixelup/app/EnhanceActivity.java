package com.pixelup.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Size;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Pick a photo from the gallery, upscale + sharpen it fully offline, compare before/after,
 * and save the result as a NEW image. The original file is only ever read.
 */
public class EnhanceActivity extends Activity {

    private static final int REQ_PICK = 1001;

    /** Sources larger than this are decoded at reduced size to avoid running out of memory. */
    private static final long MAX_SRC_PIXELS = 12_000_000L;

    private static final int PREVIEW_MAX_SIDE = 1600;

    private final Handler ui = new Handler(Looper.getMainLooper());

    // views
    private ImageView preview;
    private TextView placeholder, info, status, sharpLabel;
    private TextView chipAuto, chip2, chip3, chip4, tabOriginal, tabEnhanced;
    private View compareRow;
    private SeekBar sharpSeek;
    private ProgressBar progressBar;
    private Button btnPick, btnEnhance, btnSave;

    // state
    private Bitmap original;          // decoded source, never modified
    private Bitmap originalPreview;
    private Bitmap enhanced;          // full-size result
    private Bitmap enhancedPreview;
    private String sourceMime;
    private float requestedScale = 0f; // 0 = automatic
    private boolean loading, enhancing, saving;
    private volatile boolean cancelled;
    private volatile boolean lastDecodeReduced;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enhance);

        preview = findViewById(R.id.preview);
        placeholder = findViewById(R.id.placeholder);
        info = findViewById(R.id.info);
        status = findViewById(R.id.status);
        sharpLabel = findViewById(R.id.sharp_label);
        chipAuto = findViewById(R.id.chip_auto);
        chip2 = findViewById(R.id.chip_2);
        chip3 = findViewById(R.id.chip_3);
        chip4 = findViewById(R.id.chip_4);
        tabOriginal = findViewById(R.id.tab_original);
        tabEnhanced = findViewById(R.id.tab_enhanced);
        compareRow = findViewById(R.id.compare_row);
        sharpSeek = findViewById(R.id.sharp_seek);
        progressBar = findViewById(R.id.progress);
        btnPick = findViewById(R.id.btn_pick);
        btnEnhance = findViewById(R.id.btn_enhance);
        btnSave = findViewById(R.id.btn_save);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());
        btnPick.setOnClickListener(v -> pickImage());
        btnEnhance.setOnClickListener(v -> {
            if (enhancing) {
                cancelled = true;
                status.setText("Cancelling…");
            } else {
                startEnhance();
            }
        });
        btnSave.setOnClickListener(v -> save());

        chipAuto.setOnClickListener(v -> selectScale(0f));
        chip2.setOnClickListener(v -> selectScale(2f));
        chip3.setOnClickListener(v -> selectScale(3f));
        chip4.setOnClickListener(v -> selectScale(4f));

        tabOriginal.setOnClickListener(v -> showOriginal());
        tabEnhanced.setOnClickListener(v -> showEnhanced());

        sharpSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateSharpLabel();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        selectScale(0f);
        updateSharpLabel();
        refreshUi();
    }

    @Override
    protected void onDestroy() {
        cancelled = true;
        super.onDestroy();
    }

    // ------------------------------------------------------------------ picking / loading

    private void pickImage() {
        Intent pick = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pick.setType("image/*");
        try {
            startActivityForResult(pick, REQ_PICK);
        } catch (ActivityNotFoundException e) {
            Intent get = new Intent(Intent.ACTION_GET_CONTENT);
            get.setType("image/*");
            get.addCategory(Intent.CATEGORY_OPENABLE);
            try {
                startActivityForResult(Intent.createChooser(get, "Choose an image"), REQ_PICK);
            } catch (ActivityNotFoundException e2) {
                toast("No gallery app found");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            loadImage(data.getData());
        }
    }

    private void loadImage(final Uri uri) {
        loading = true;
        status.setText("Loading image…");
        refreshUi();
        new Thread(() -> {
            Bitmap bmp = null;
            Bitmap prev = null;
            String mime = null;
            boolean ok = false;
            try {
                bmp = decode(uri);
                mime = getContentResolver().getType(uri);
                prev = makePreview(bmp);
                ok = true;
            } catch (Throwable t) {
                ok = false;
            }
            final Bitmap fBmp = bmp, fPrev = prev;
            final String fMime = mime;
            final boolean fOk = ok;
            ui.post(() -> onLoaded(fOk, fBmp, fPrev, fMime));
        }).start();
    }

    private Bitmap decode(Uri uri) throws IOException {
        lastDecodeReduced = false;
        ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
        return ImageDecoder.decodeBitmap(source, (decoder, imageInfo, s) -> {
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE); // we need readable pixels
            Size size = imageInfo.getSize();
            long px = (long) size.getWidth() * size.getHeight();
            if (px > MAX_SRC_PIXELS) {
                double f = Math.sqrt((double) MAX_SRC_PIXELS / px);
                decoder.setTargetSize(Math.max(1, (int) (size.getWidth() * f)),
                        Math.max(1, (int) (size.getHeight() * f)));
                lastDecodeReduced = true;
            }
        });
    }

    private void onLoaded(boolean ok, Bitmap bmp, Bitmap prev, String mime) {
        loading = false;
        if (!ok || bmp == null) {
            status.setText("");
            toast("Couldn't open that image");
            refreshUi();
            return;
        }
        original = bmp;
        originalPreview = prev;
        sourceMime = mime;
        enhanced = null;          // a new photo invalidates any previous result
        enhancedPreview = null;
        status.setText(lastDecodeReduced ? "Very large photo: working from a reduced-size copy." : "");
        showOriginal();
        updateInfo();
        refreshUi();
    }

    private static Bitmap makePreview(Bitmap b) {
        int longSide = Math.max(b.getWidth(), b.getHeight());
        if (longSide <= PREVIEW_MAX_SIDE) {
            return b;
        }
        float f = PREVIEW_MAX_SIDE / (float) longSide;
        return Bitmap.createScaledBitmap(b,
                Math.max(1, Math.round(b.getWidth() * f)),
                Math.max(1, Math.round(b.getHeight() * f)), true);
    }

    // ------------------------------------------------------------------ enhancing

    private void startEnhance() {
        if (original == null || enhancing || loading) {
            return;
        }
        cancelled = false;
        enhancing = true;
        progressBar.setProgress(0);
        status.setText("Enhancing… 0%");
        refreshUi();

        final Bitmap src = original;
        final float scaleReq = requestedScale;
        final float amount = sharpSeek.getProgress() / 100f * 1.5f;

        new Thread(() -> {
            Bitmap result = null;
            Bitmap resultPreview = null;
            String error = null;
            try {
                final int sw = src.getWidth();
                final int sh = src.getHeight();
                float s = Upscaler.effectiveScale(sw, sh, scaleReq);
                final int dw = Upscaler.scaledSize(sw, s);
                final int dh = Upscaler.scaledSize(sh, s);

                int[] px = new int[sw * sh];
                src.getPixels(px, 0, sw, 0, 0, sw, sh);

                final Bitmap dst = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888);
                final int[] lastPercent = {-1};

                boolean finished = Upscaler.run(px, sw, sh, dw, dh, amount,
                        (y, row) -> dst.setPixels(row, 0, dw, 0, y, dw, 1),
                        new Upscaler.Progress() {
                            @Override
                            public void onProgress(final int percent) {
                                if (percent != lastPercent[0]) {
                                    lastPercent[0] = percent;
                                    ui.post(() -> {
                                        progressBar.setProgress(percent);
                                        status.setText("Enhancing… " + percent + "%");
                                    });
                                }
                            }

                            @Override
                            public boolean isCancelled() {
                                return cancelled;
                            }
                        });

                if (finished) {
                    result = dst;
                    resultPreview = makePreview(dst);
                }
            } catch (Throwable t) {
                error = (t instanceof OutOfMemoryError)
                        ? "Not enough memory for this image. Try a smaller upscale."
                        : "Enhancement failed.";
            }
            final Bitmap fResult = result, fPreview = resultPreview;
            final String fError = error;
            ui.post(() -> onEnhanceDone(fResult, fPreview, fError));
        }).start();
    }

    private void onEnhanceDone(Bitmap result, Bitmap resultPreview, String error) {
        enhancing = false;
        progressBar.setProgress(0);
        if (error != null) {
            status.setText("");
            toast(error);
        } else if (result == null) {
            status.setText("Cancelled.");
        } else {
            enhanced = result;
            enhancedPreview = resultPreview;
            status.setText("Done: " + result.getWidth() + " × " + result.getHeight()
                    + " px. Your original is untouched.");
            showEnhanced();
        }
        refreshUi();
    }

    // ------------------------------------------------------------------ saving

    private void save() {
        if (enhanced == null || saving || enhancing) {
            return;
        }
        saving = true;
        status.setText("Saving…");
        refreshUi();

        final Bitmap bmp = enhanced;
        final boolean jpeg = "image/jpeg".equals(sourceMime);

        new Thread(() -> {
            Uri uri = null;
            boolean ok = false;
            try {
                String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                ContentValues v = new ContentValues();
                v.put(MediaStore.Images.Media.DISPLAY_NAME, "Enhanced_" + stamp + (jpeg ? ".jpg" : ".png"));
                v.put(MediaStore.Images.Media.MIME_TYPE, jpeg ? "image/jpeg" : "image/png");
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PixelUp");
                v.put(MediaStore.Images.Media.IS_PENDING, 1);

                Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                uri = getContentResolver().insert(collection, v);
                if (uri == null) {
                    throw new IOException("insert failed");
                }
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os == null) {
                        throw new IOException("no output stream");
                    }
                    boolean written = bmp.compress(
                            jpeg ? Bitmap.CompressFormat.JPEG : Bitmap.CompressFormat.PNG,
                            jpeg ? 95 : 100, os);
                    if (!written) {
                        throw new IOException("compress failed");
                    }
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
                ok = true;
            } catch (Throwable t) {
                if (uri != null) {
                    try {
                        getContentResolver().delete(uri, null, null); // don't leave a half-written file
                    } catch (Throwable ignored) {
                    }
                }
            }
            final boolean fOk = ok;
            ui.post(() -> {
                saving = false;
                status.setText(fOk ? "Saved to Pictures/PixelUp." : "");
                toast(fOk ? "Saved to your gallery" : "Couldn't save the image");
                refreshUi();
            });
        }).start();
    }

    // ------------------------------------------------------------------ UI helpers

    private void selectScale(float s) {
        requestedScale = s;
        chipAuto.setSelected(s == 0f);
        chip2.setSelected(s == 2f);
        chip3.setSelected(s == 3f);
        chip4.setSelected(s == 4f);
        updateInfo();
    }

    private void updateInfo() {
        if (original == null) {
            info.setText("");
            return;
        }
        int sw = original.getWidth();
        int sh = original.getHeight();
        float s = Upscaler.effectiveScale(sw, sh, requestedScale);
        int dw = Upscaler.scaledSize(sw, s);
        int dh = Upscaler.scaledSize(sh, s);
        String text = sw + " × " + sh + "  →  " + dw + " × " + dh + " px";
        if (s == 1f) {
            text += "\nAlready high resolution: sharpening only";
        } else {
            String f = (s == Math.floor(s)) ? String.valueOf((int) s) : String.format(Locale.US, "%.2f", s);
            text += "  (" + f + "×)";
            if (requestedScale > 0f && s < requestedScale) {
                text += "\nReduced to fit your phone's memory";
            }
        }
        info.setText(text);
    }

    private void updateSharpLabel() {
        sharpLabel.setText("Sharpness: " + sharpSeek.getProgress() + "%");
    }

    private void showOriginal() {
        if (originalPreview == null) {
            return;
        }
        preview.setImageBitmap(originalPreview);
        placeholder.setVisibility(View.GONE);
        tabOriginal.setSelected(true);
        tabEnhanced.setSelected(false);
    }

    private void showEnhanced() {
        if (enhancedPreview == null) {
            showOriginal();
            return;
        }
        preview.setImageBitmap(enhancedPreview);
        placeholder.setVisibility(View.GONE);
        tabOriginal.setSelected(false);
        tabEnhanced.setSelected(true);
    }

    private void refreshUi() {
        boolean busy = loading || enhancing || saving;
        progressBar.setVisibility((loading || enhancing) ? View.VISIBLE : View.GONE);
        progressBar.setIndeterminate(loading);

        setOn(btnPick, !busy);
        btnEnhance.setText(enhancing ? "Cancel" : "Enhance");
        setOn(btnEnhance, !loading && !saving && (enhancing || original != null));
        setOn(btnSave, enhanced != null && !busy);

        compareRow.setVisibility(enhanced != null ? View.VISIBLE : View.GONE);

        boolean chipsOn = !enhancing;
        setOn(chipAuto, chipsOn);
        setOn(chip2, chipsOn);
        setOn(chip3, chipsOn);
        setOn(chip4, chipsOn);
        setOn(sharpSeek, chipsOn);
    }

    private static void setOn(View v, boolean on) {
        v.setEnabled(on);
        v.setAlpha(on ? 1f : 0.4f);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
