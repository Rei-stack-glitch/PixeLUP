package com.pixelup.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/**
 * Launcher entry point with no UI of its own: shows the welcome screen on the very first
 * launch and goes straight to the home screen on every launch after that.
 */
public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Class<?> next = Prefs.isWelcomeShown(this) ? HomeActivity.class : WelcomeActivity.class;
        startActivity(new Intent(this, next));
        finish();
    }
}
