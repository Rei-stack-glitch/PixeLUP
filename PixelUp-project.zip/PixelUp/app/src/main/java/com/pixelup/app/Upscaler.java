package com.pixelup.app;

/**
 * Offline image upscaler with no Android dependencies, so it can be checked on a plain JVM.
 *
 * Pipeline: premultiply alpha -> separable Lanczos-3 resample (horizontal, then vertical)
 *           -> light 3x3 unsharp mask -> un-premultiply.
 *
 * Output rows are streamed through a {@link RowSink}, so the full-size result never needs a
 * second int[] copy in memory (the caller writes each row straight into its Bitmap).
 * The source array is only read, never modified.
 */
public final class Upscaler {

    /** Receives finished output rows, top to bottom. The array is reused: copy it if you keep it. */
    public interface RowSink {
        void writeRow(int y, int[] argbRow);
    }

    public interface Progress {
        void onProgress(int percent);

        boolean isCancelled();
    }

    /** Upper bound on output size, to keep memory use sane on phones. */
    public static final long MAX_OUT_PIXELS = 16_000_000L;

    /** "Auto" aims for the long side to reach about this many pixels. */
    public static final int AUTO_TARGET_LONG_SIDE = 3000;

    private static final int TAPS = 6; // Lanczos-3 => 6 source samples per output sample

    private Upscaler() {
    }

    /**
     * Scale factor actually used.
     *
     * @param requested 0 = automatic, otherwise the factor the user asked for (e.g. 2, 3, 4)
     * @return 1 (enhance only) or a factor of at least 1.25, never above what MAX_OUT_PIXELS allows
     */
    public static float effectiveScale(int sw, int sh, float requested) {
        double cap = Math.sqrt(MAX_OUT_PIXELS / ((double) sw * sh));
        double s;
        if (requested <= 0f) {
            int longSide = Math.max(sw, sh);
            s = Math.ceil(AUTO_TARGET_LONG_SIDE / (double) longSide);
            s = Math.max(1.0, Math.min(4.0, s));
        } else {
            s = requested;
        }
        if (s > cap) {
            s = Math.floor(cap * 4.0) / 4.0;
        }
        return s < 1.25 ? 1f : (float) s;
    }

    public static int scaledSize(int n, float scale) {
        return Math.max(1, Math.round(n * scale));
    }

    /**
     * @param src     source pixels, non-premultiplied ARGB (as Bitmap.getPixels returns them)
     * @param sharpen unsharp-mask strength, 0 = off, ~0.6 = gentle, 1.5 = strong
     * @return true when finished, false when cancelled
     */
    public static boolean run(int[] src, int sw, int sh, int dw, int dh, float sharpen,
                              RowSink sink, Progress progress) {
        if (sw < 1 || sh < 1 || src.length < (long) sw * sh) {
            throw new IllegalArgumentException("bad source");
        }
        if (dw < sw || dh < sh) {
            throw new IllegalArgumentException("this resampler only enlarges");
        }
        if ((long) dw * sh > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("image too large");
        }

        int[] xi = new int[dw * TAPS];
        float[] xw = new float[dw * TAPS];
        int[] yi = new int[dh * TAPS];
        float[] yw = new float[dh * TAPS];
        buildWeights(sw, dw, xi, xw);
        buildWeights(sh, dh, yi, yw);

        // ---- Pass 1: horizontal. Result is premultiplied ARGB, sh rows of dw pixels. ----
        int[] inter = new int[dw * sh];
        for (int y = 0; y < sh; y++) {
            if (progress != null && progress.isCancelled()) {
                return false;
            }
            int rowOff = y * sw;
            int outOff = y * dw;
            for (int x = 0; x < dw; x++) {
                float a = 0f, r = 0f, g = 0f, b = 0f;
                int base = x * TAPS;
                for (int k = 0; k < TAPS; k++) {
                    int p = src[rowOff + xi[base + k]];
                    float wa = xw[base + k] * (p >>> 24);
                    a += wa;
                    float wk = wa * (1f / 255f); // weight * alpha/255 => premultiplied contribution
                    r += wk * ((p >> 16) & 255);
                    g += wk * ((p >> 8) & 255);
                    b += wk * (p & 255);
                }
                inter[outOff + x] = (c8(a) << 24) | (c8(r) << 16) | (c8(g) << 8) | c8(b);
            }
            report(progress, (int) (40L * (y + 1) / sh));
        }

        // ---- Pass 2: vertical + sharpen, one output row at a time (3-row sliding window). ----
        float[] accA = new float[dw];
        float[] accR = new float[dw];
        float[] accG = new float[dw];
        float[] accB = new float[dw];
        int[] prev = new int[dw];
        int[] cur = new int[dw];
        int[] next = new int[dw];
        int[] out = new int[dw];

        verticalRow(inter, dw, yi, yw, 0, accA, accR, accG, accB, cur);
        System.arraycopy(cur, 0, prev, 0, dw);

        for (int y = 0; y < dh; y++) {
            if (progress != null && progress.isCancelled()) {
                return false;
            }
            if (y + 1 < dh) {
                verticalRow(inter, dw, yi, yw, y + 1, accA, accR, accG, accB, next);
            } else {
                System.arraycopy(cur, 0, next, 0, dw);
            }
            sharpenRow(prev, cur, next, out, dw, sharpen);
            sink.writeRow(y, out);

            int[] t = prev;
            prev = cur;
            cur = next;
            next = t;

            if ((y & 15) == 0 || y == dh - 1) {
                report(progress, 40 + (int) (60L * (y + 1) / dh));
            }
        }
        return true;
    }

    // ------------------------------------------------------------------------------------

    private static void verticalRow(int[] inter, int dw, int[] yi, float[] yw, int y,
                                    float[] aA, float[] aR, float[] aG, float[] aB, int[] dst) {
        java.util.Arrays.fill(aA, 0f);
        java.util.Arrays.fill(aR, 0f);
        java.util.Arrays.fill(aG, 0f);
        java.util.Arrays.fill(aB, 0f);
        int base = y * TAPS;
        for (int k = 0; k < TAPS; k++) {
            float w = yw[base + k];
            if (w > -1e-6f && w < 1e-6f) {
                continue; // contributes nothing (e.g. scale 1 hits exact sample centres)
            }
            int off = yi[base + k] * dw;
            for (int x = 0; x < dw; x++) {
                int p = inter[off + x];
                aA[x] += w * (p >>> 24);
                aR[x] += w * ((p >> 16) & 255);
                aG[x] += w * ((p >> 8) & 255);
                aB[x] += w * (p & 255);
            }
        }
        for (int x = 0; x < dw; x++) {
            dst[x] = (c8(aA[x]) << 24) | (c8(aR[x]) << 16) | (c8(aG[x]) << 8) | c8(aB[x]);
        }
    }

    /** 3x3 Gaussian unsharp mask on premultiplied colour, then convert to straight ARGB. */
    private static void sharpenRow(int[] p, int[] c, int[] n, int[] out, int w, float amount) {
        for (int x = 0; x < w; x++) {
            int v = c[x];
            int a = v >>> 24;
            if (amount == 0f || a == 0) {
                out[x] = unpremul(a, (v >> 16) & 255, (v >> 8) & 255, v & 255);
                continue;
            }
            int xl = x > 0 ? x - 1 : 0;
            int xr = x < w - 1 ? x + 1 : x;
            int r = sharpChannel(p, c, n, xl, x, xr, 16, amount, a);
            int g = sharpChannel(p, c, n, xl, x, xr, 8, amount, a);
            int b = sharpChannel(p, c, n, xl, x, xr, 0, amount, a);
            out[x] = unpremul(a, r, g, b);
        }
    }

    private static int sharpChannel(int[] p, int[] c, int[] n, int xl, int x, int xr,
                                    int shift, float amount, int alpha) {
        int sum = ch(p[xl], shift) + 2 * ch(p[x], shift) + ch(p[xr], shift)
                + 2 * (ch(c[xl], shift) + 2 * ch(c[x], shift) + ch(c[xr], shift))
                + ch(n[xl], shift) + 2 * ch(n[x], shift) + ch(n[xr], shift);
        float blur = sum * (1f / 16f);
        float v = ch(c[x], shift);
        float o = v + amount * (v - blur);
        int i = (int) (o + 0.5f);
        if (o < 0f || i < 0) {
            i = 0;
        }
        return i > alpha ? alpha : i; // premultiplied colour can never exceed alpha
    }

    private static int unpremul(int a, int r, int g, int b) {
        if (a == 255) {
            return 0xFF000000 | (r << 16) | (g << 8) | b;
        }
        if (a == 0) {
            return 0;
        }
        r = Math.min(255, (r * 255 + a / 2) / a);
        g = Math.min(255, (g * 255 + a / 2) / a);
        b = Math.min(255, (b * 255 + a / 2) / a);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static void buildWeights(int srcLen, int dstLen, int[] idx, float[] wts) {
        double ratio = (double) srcLen / dstLen; // <= 1 when enlarging
        double[] tmp = new double[TAPS];
        for (int d = 0; d < dstLen; d++) {
            double center = (d + 0.5) * ratio - 0.5;
            int first = (int) Math.floor(center) - 2;
            double sum = 0;
            for (int k = 0; k < TAPS; k++) {
                int i = first + k;
                double w = lanczos3(center - i);
                tmp[k] = w;
                sum += w;
                idx[d * TAPS + k] = i < 0 ? 0 : (i >= srcLen ? srcLen - 1 : i);
            }
            for (int k = 0; k < TAPS; k++) {
                wts[d * TAPS + k] = (float) (tmp[k] / sum);
            }
        }
    }

    private static double lanczos3(double x) {
        x = Math.abs(x);
        if (x < 1e-9) {
            return 1.0;
        }
        if (x >= 3.0) {
            return 0.0;
        }
        double px = Math.PI * x;
        return 3.0 * Math.sin(px) * Math.sin(px / 3.0) / (px * px);
    }

    private static int ch(int p, int shift) {
        return (p >> shift) & 255;
    }

    private static int c8(float v) {
        int i = (int) (v + 0.5f);
        return i < 0 ? 0 : (i > 255 ? 255 : i);
    }

    private static void report(Progress p, int percent) {
        if (p != null) {
            p.onProgress(Math.min(100, percent));
        }
    }
}
