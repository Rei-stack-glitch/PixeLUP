package com.pixelup.app;

import android.content.Context;

/** Tiny wrapper around SharedPreferences for the one-time welcome flag. */
final class Prefs {
    private static final String FILE = "pixelup_prefs";
    private static final String KEY_WELCOME_SHOWN = "welcome_shown";

    private Prefs() {
    }

    static boolean isWelcomeShown(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY_WELCOME_SHOWN, false);
    }

    static void markWelcomeShown(Context c) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY_WELCOME_SHOWN, true).apply();
    }
}
