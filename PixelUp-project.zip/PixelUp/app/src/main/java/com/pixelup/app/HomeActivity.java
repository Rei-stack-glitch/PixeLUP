package com.pixelup.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

/** Main screen: four cards in a 2x2 grid. Only "Enhance &amp; Upscale" is wired up so far. */
public class HomeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        View.OnClickListener comingSoon =
                v -> Toast.makeText(this, "Coming soon", Toast.LENGTH_SHORT).show();

        setupCard(R.id.card_enhance, "✨", "Enhance & Upscale", "Sharpen and enlarge a photo",
                v -> startActivity(new Intent(this, EnhanceActivity.class)), 0);
        setupCard(R.id.card_two, "🧹", "Denoise", "Coming soon", comingSoon, 1);
        setupCard(R.id.card_three, "🎨", "Colorize", "Coming soon", comingSoon, 2);
        setupCard(R.id.card_four, "🔍", "Compare", "Coming soon", comingSoon, 3);
    }

    private void setupCard(int viewId, String icon, String title, String subtitle,
                           View.OnClickListener onClick, int order) {
        View card = findViewById(viewId);
        ((TextView) card.findViewById(R.id.card_icon)).setText(icon);
        ((TextView) card.findViewById(R.id.card_title)).setText(title);
        ((TextView) card.findViewById(R.id.card_subtitle)).setText(subtitle);
        card.setOnClickListener(onClick);

        // Press feedback: the card shrinks slightly while held. Returns false so clicks still fire.
        card.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                    break;
                default:
                    break;
            }
            return false;
        });

        // Staggered entrance.
        card.setAlpha(0f);
        card.setTranslationY(48f);
        card.animate().alpha(1f).translationY(0f).setStartDelay(order * 90L).setDuration(350).start();
    }
}
