package com.pixelup.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/** One-time welcome screen. Once it has been shown it is never launched again. */
public class WelcomeActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        // Mark as shown the moment it appears, so it can never come back.
        Prefs.markWelcomeShown(this);

        // Gentle entrance animation.
        View logo = findViewById(R.id.welcome_logo);
        logo.setScaleX(0.4f);
        logo.setScaleY(0.4f);
        logo.setAlpha(0f);
        logo.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(600).start();

        findViewById(R.id.btn_start).setOnClickListener(v -> {
            startActivity(new Intent(this, HomeActivity.class));
            finish();
        });
    }
}
